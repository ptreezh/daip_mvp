"""Implements the DatabaseManager for all database interactions."""

from typing import List, Optional

from sqlalchemy import create_engine, delete, insert, select
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.engine import Engine

from daip_live.core.models import AgentState, DialogueTurn, KnowledgeSource, Session
from daip_live.persistence.tables import (
    dialogue_turns_table,
    knowledge_sources_table,
    metadata_obj,
    sessions_table,
)


class DatabaseManager:
    """Encapsulates all direct interactions with the SQLite database."""

    def __init__(self, db_path: str):
        if db_path == ":memory:":
            self.engine: Engine = create_engine("sqlite:///:memory:")
        elif db_path.startswith("sqlite:///"):
            self.engine: Engine = create_engine(db_path)
        else:
            self.engine: Engine = create_engine(f"sqlite:///{db_path}")
        self._create_tables()

    def _create_tables(self):
        metadata_obj.create_all(self.engine)

    # --- Session Methods (New Implementation) ---

    def save_session(self, session: Session):
        """Saves or updates a session and its dialogue turns in a transaction."""
        session_dict = session.dict()
        session_history = session_dict.pop("history", [])

        # Convert AgentState enum to its string value for storage
        session_dict["status"] = session_dict["status"].name

        upsert_stmt = sqlite_insert(sessions_table).values(session_dict)
        upsert_stmt = upsert_stmt.on_conflict_do_update(
            index_elements=["session_id"],
            set_=dict(upsert_stmt.excluded)
        )

        with self.engine.begin() as conn:
            # 1. Upsert the session record
            conn.execute(upsert_stmt)

            # 2. Delete old dialogue turns for this session to ensure consistency
            conn.execute(delete(dialogue_turns_table).where(dialogue_turns_table.c.session_id == session.session_id))

            # 3. Insert new dialogue turns if any
            if session_history:
                turns_to_insert = [
                    {"session_id": session.session_id, **turn} for turn in session_history
                ]
                conn.execute(insert(dialogue_turns_table), turns_to_insert)

    def get_session(self, session_id: str) -> Optional[Session]:
        """Retrieves a full session, including its dialogue history."""
        session_stmt = select(sessions_table).where(sessions_table.c.session_id == session_id)
        turns_stmt = select(dialogue_turns_table).where(dialogue_turns_table.c.session_id == session_id).order_by(dialogue_turns_table.c.timestamp)

        with self.engine.connect() as conn:
            session_row = conn.execute(session_stmt).first()
            if not session_row:
                return None

            session_data = dict(session_row._asdict())
            # Convert status string back to AgentState enum
            session_data["status"] = AgentState[session_data["status"]]

            turns_rows = conn.execute(turns_stmt).all()
            history = [DialogueTurn(**row._asdict()) for row in turns_rows]
            session_data["history"] = history

        return Session(**session_data)

    def list_sessions(self) -> List[Session]:
        """Retrieves all sessions (metadata only, without history)."""
        stmt = select(sessions_table).order_by(sessions_table.c.start_time.desc())
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).all()

        sessions = []
        for row in rows:
            session_data = dict(row._asdict())
            session_data["status"] = AgentState[session_data["status"]]
            sessions.append(Session(**session_data))
        return sessions

    def delete_session(self, session_id: str) -> bool:
        """Deletes a session and its associated dialogue turns."""
        with self.engine.begin() as conn:
            # Delete dialogue turns first (foreign key dependency)
            turns_deleted = conn.execute(delete(dialogue_turns_table).where(dialogue_turns_table.c.session_id == session_id))
            # Delete the session
            session_deleted = conn.execute(delete(sessions_table).where(sessions_table.c.session_id == session_id))
            return session_deleted.rowcount > 0

    def clear_all_sessions(self) -> int:
        """Deletes all sessions and their dialogue turns from the database."""
        with self.engine.begin() as conn:
            # Order matters due to foreign key constraints
            conn.execute(delete(dialogue_turns_table))
            result = conn.execute(delete(sessions_table))
            return result.rowcount

    # --- Knowledge Source Methods (Unchanged) ---

    def get_knowledge_source_by_path(self, file_path: str) -> Optional[KnowledgeSource]:
        stmt = select(knowledge_sources_table).where(knowledge_sources_table.c.file_path == file_path)
        with self.engine.connect() as conn:
            row = conn.execute(stmt).first()
        return KnowledgeSource(**row._asdict()) if row else None

    def get_all_knowledge_sources(self) -> List[KnowledgeSource]:
        stmt = select(knowledge_sources_table)
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).all()
        return [KnowledgeSource(**row._asdict()) for row in rows]

    def upsert_knowledge_source(self, source: KnowledgeSource) -> KnowledgeSource:
        insert_stmt = sqlite_insert(knowledge_sources_table).values(
            source.model_dump(exclude_none=True)
        )
        update_stmt = insert_stmt.on_conflict_do_update(
            index_elements=["file_path"],
            set_=dict(
                file_hash=insert_stmt.excluded.file_hash,
                status=insert_stmt.excluded.status,
                indexed_at=insert_stmt.excluded.indexed_at,
            )
        ).returning(knowledge_sources_table)

        with self.engine.begin() as conn:
            result = conn.execute(update_stmt)
            upserted_row = result.first()

        if not upserted_row:
            raise RuntimeError("Failed to upsert knowledge source.")

        return KnowledgeSource(**upserted_row._asdict())

    def delete_knowledge_source(self, file_path: str) -> None:
        stmt = delete(knowledge_sources_table).where(knowledge_sources_table.c.file_path == file_path)
        with self.engine.begin() as conn:
            conn.execute(stmt)

    def get_knowledge_sources_by_ids(self, ids: List[int]) -> List[KnowledgeSource]:
        """Retrieves a list of KnowledgeSource objects by their primary key IDs."""
        stmt = select(knowledge_sources_table).where(knowledge_sources_table.c.id.in_(ids))
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).all()
        return [KnowledgeSource(**row._asdict()) for row in rows]
