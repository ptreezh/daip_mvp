# Core framework components
